Hello! Thanks for reading me!

INSTRUCTIONS to run BusinessCardParser C# Windows Form Application:

If running on a Windows machine, then...
1. Execute the BusinessCardParser.exe file located in \BusinessCardParser\BusinessCardParser\bin\Debug

If running on a Mac, then...
1. Download Mono from http://www.mono-project.com
2. Open the Mono terminal as described at http://www.mono-project.com/docs/about-mono/supported-platforms/osx/
3. Run the following command: mono BusinessCardParser.exe

If running on Linux, then...
1. Download Wine
2. Run the following command from the terminal:
$ wine BusinessCardParser.exe
For more detailed instructions, see https://www.winehq.org/docs/wineusr-guide/running-wine